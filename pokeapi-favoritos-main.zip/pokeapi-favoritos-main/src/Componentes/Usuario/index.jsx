import { useState } from 'react'
import './style.css'

function Usuario() {

 return (
    <>
<h1>Usuario</h1>
      </>
  )
}

export default Usuario
