import { useState } from 'react'
import './style.css'

function Favoritos() {

 return (
    <>
<h1>Favoritos</h1>
      </>
  )
}

export default Favoritos
