import { useState } from 'react'
import './style.css'

function Aleatorios() {

 return (
    <>
<h1>Aleatorios</h1>
      </>
  )
}

export default Aleatorios
