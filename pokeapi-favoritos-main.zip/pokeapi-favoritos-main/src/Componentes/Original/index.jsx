import { useState } from 'react'
import './style.css'

function Original() {

 return (
    <>
<h1>Original</h1>
      </>
  )
}

export default Original
